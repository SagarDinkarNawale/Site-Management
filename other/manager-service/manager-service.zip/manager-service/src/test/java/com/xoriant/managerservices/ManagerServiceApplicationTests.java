package com.xoriant.managerservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
